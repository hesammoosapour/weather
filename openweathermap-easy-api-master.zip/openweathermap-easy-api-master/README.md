# openweathermap-easy-api
Provides easy and clean access to the open weather map api. can easily be integrated in PHP solutions both plain PHP solutions and framwork solutions
You can find further info on the API here http://openweathermap.org/api if you need any help with either my code or the API dont hesitate to contact me.

Remember to include a link to openweathermap when using the free api plan
